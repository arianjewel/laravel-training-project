<div class="modal fade" id="edit<?php echo e($brand->id); ?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Brand</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('update-brand')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Brand Name</label>
                        <input type="text" value="<?php echo e($brand->brand_name); ?>" name="brand_name" class="form-control" placeholder="Enter Category Name">
                        <input type="hidden" value="<?php echo e($brand->id); ?>" name="id" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Brand Description</label>
                        <textarea class="form-control" name="brand_desc"  placeholder="Category Description"><?php echo e($brand->brand_desc); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Brand Image</label>
                        <input type="file" name="brand_image" class="form-control-file">
                        <img src="<?php echo e(asset($brand->brand_image)); ?>">
                    </div>
                    <div class="form-group">
                        <label>Publication Status</label>
                        <input type="radio" name="status" value="1" <?php echo e($brand->status == 1?'Checked':''); ?>>
                        <label>Published</label>
                        <input type="radio" name="status" value="0" <?php echo e($brand->status == 0?'Checked':''); ?>>
                        <label>Unpublished</label>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="btn" class="btn btn-primary">Update Brand</button>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lara12\resources\views/admin/brand/edit-brand.blade.php ENDPATH**/ ?>