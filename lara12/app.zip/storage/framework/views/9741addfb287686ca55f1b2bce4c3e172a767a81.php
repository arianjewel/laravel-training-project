<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <?php if(Session::get('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('message')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <div class="row">
            <h2>Add Product</h2>
            <div class="col-md-12">
                <?php echo e(Form::open(['route'=>'new-product','enctype'=>'multipart/form-data'])); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('Product Name')); ?>

                        <?php echo e(Form::text('product_name','',['class'=>'form-control','placeholder'=>'Product Name'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('Category Name')); ?>

                        <select name="cat_id" class="form-control">
                            <option>---Select Category---</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->cat_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('Brand Name')); ?>

                        <select name="brand_id" class="form-control">
                            <option>---Select Brand---</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('Product Price')); ?>

                        <?php echo e(Form::text('product_price','',['class'=>'form-control','placeholder'=>'Product Price'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('Short Description')); ?>

                        <?php echo e(Form::textarea('short_desc','',['class'=>'form-control','rows'=>'3'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('Long Description')); ?>

                        <?php echo e(Form::textarea('long_desc','',['class'=>'form-control','rows'=>'3','id'=>'editor'])); ?>

                    </div>
                <div class="form-group">
                    <?php echo e(Form::label('Product Size')); ?>

                    <select name="product_size" class="form-control">
                        <option>---Select Product Size---</option>
                        <option value="xl">Xl</option>
                        <option value="l">L</option>
                        <option value="m">M</option>
                        <option value="s">S</option>
                    </select>
                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Product Quantity')); ?>

                    <?php echo e(Form::number('product_qty', '',['class'=>'form-control'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Product Image')); ?>

                    <input type="file" class="form-control-file" name="main_image">
                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Image Gallery')); ?>

                    <input type="file" class="form-control-file" name="imagefile[]" multiple>
                </div>
                <div class="form-group">
                    <?php echo e(Form::submit('Add Product',['class'=>'btn btn-primary'])); ?>

                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>














<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara12\resources\views/admin/product/add-product.blade.php ENDPATH**/ ?>