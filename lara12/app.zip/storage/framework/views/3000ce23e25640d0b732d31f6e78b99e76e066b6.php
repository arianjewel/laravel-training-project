<h1>Hello Home</h1>

<a href="<?php echo e(route('home')); ?>">Home</a>
<a href="<?php echo e(route('bitm')); ?>">Test</a>
<hr>

<form action="<?php echo e(route('my-form')); ?>" method="post">
    <?php echo csrf_field(); ?>
    Name: <input type="text" name="name">
    <input type="submit" name="btn">
</form>

<?php /**PATH C:\xampp\htdocs\lara12\resources\views/home/home.blade.php ENDPATH**/ ?>