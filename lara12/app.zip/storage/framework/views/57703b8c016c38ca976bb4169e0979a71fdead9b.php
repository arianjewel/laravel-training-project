<h1>Hello Demo</h1>

<a href="<?php echo e(url('/test')); ?>">Home</a>
<a href="<?php echo e(url('/bitm')); ?>">Test</a>

<h2><?php echo e($name); ?></h2>
<h2><?php echo e($city); ?></h2><?php /**PATH C:\xampp\htdocs\lara12\resources\views/demo.blade.php ENDPATH**/ ?>