<?php $__env->startSection('body'); ?>
    <div class="container">
        <?php if(Session::get('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('message')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    <th>Category Name</th>
                                    <th>Category Description</th>
                                    <th>Publication Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php ($i = 1); ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($category->cat_name); ?></td>
                                    <td><?php echo e($category->cat_desc); ?></td>
                                    <td><?php echo e($category->status==1?'Published':'Unpublished'); ?></td>
                                    <td>
                                        <?php if($category->status==1): ?>
                                        <a href="<?php echo e(route('published-category',['id'=>$category->id])); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-arrow-up"></i>
                                        </a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('unpublished-category',['id'=>$category->id])); ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-arrow-down"></i>
                                        </a>
                                        <?php endif; ?>
                                        <a href="" class="btn btn-sm btn-success" data-toggle="modal" data-target="#edit<?php echo e($category->id); ?>">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?php echo e(route('delete-category',['id'=>$category->id])); ?>" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>

                                <?php echo $__env->make('admin.category.edit-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara12\resources\views/admin/category/manage-category.blade.php ENDPATH**/ ?>